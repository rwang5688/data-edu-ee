CREATE TABLE ed_level(
    ed_level_id INT AUTO_INCREMENT PRIMARY KEY,
    ed_level_code VARCHAR(10),
    ed_level_desc VARCHAR(40)
)