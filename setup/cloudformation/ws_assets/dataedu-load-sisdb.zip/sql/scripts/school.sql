CREATE TABLE school(
    school_id INT AUTO_INCREMENT PRIMARY KEY,
    school_name VARCHAR(50),
    relative_website_url VARCHAR(50),
    university_id BIGINT
)