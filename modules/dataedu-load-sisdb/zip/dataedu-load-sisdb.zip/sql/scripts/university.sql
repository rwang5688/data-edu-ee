CREATE TABLE university(
    university_id INT AUTO_INCREMENT PRIMARY KEY,
    university_name VARCHAR(50),
    website_url  VARCHAR(50)
)