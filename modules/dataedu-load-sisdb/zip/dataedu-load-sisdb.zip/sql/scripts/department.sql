CREATE TABLE department(
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    department_name VARCHAR(100),
    department_code VARCHAR(4),
    school_id BIGINT
)